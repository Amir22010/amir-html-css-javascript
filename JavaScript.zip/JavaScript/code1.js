var scoops = 5;
while (scoops > 0) {
document.write("Another scoop!<br>");
scoops = scoops - 1;
}
document.write("Life without ice cream isn't the same");