var flavours = ["vanilla","butterScotch","lavender"];
flavours[2]="strawberry";
var myflavours = flavours[2];
alert(myflavours);
